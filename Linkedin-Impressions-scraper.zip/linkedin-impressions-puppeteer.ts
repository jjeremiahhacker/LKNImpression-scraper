import { PuppeteerCrawler, Actor } from '@crawlee/puppeteer';

await Actor.init();
const { postUrl, liAtCookie, proxyConfiguration } = await Actor.getInput();

const proxyConfig = proxyConfiguration
  ? await Actor.createProxyConfiguration(proxyConfiguration)
  : undefined;

const crawler = new PuppeteerCrawler({
  proxyConfiguration: proxyConfig,
  launchContext: {
    launcher: undefined, // defaults to puppeteer
    launchOptions: { headless: true },
  },
  preNavigationHooks: [
    async ({ page }) => {
      await page.setCookie({
        name: 'li_at',
        value: liAtCookie,
        domain: '.linkedin.com',
        path: '/',
        httpOnly: true,
        secure: true,
      });
    },
  ],
  requestHandler: async ({ page, request }) => {
    await page.goto(request.url, { waitUntil: 'networkidle2' });
    await page.click('button[aria-label*="View analytics"]');
    await page.waitForSelector('span.analytics-impressions', { timeout: 15000 });
    const text = await page.$eval(
      'span.analytics-impressions',
      el => el.textContent?.trim() || ''
    );
    const count = parseInt(text.replace(/\D/g, ''), 10);
    await Actor.pushData({ url: request.url, impressions: count, scrapedAt: new Date().toISOString() });
  },
  failedRequestHandler: async ({ request, log }) => {
    log.error(`Failed scraping ${request.url}`);
    await Actor.pushData({ url: request.url, error: request.error() });
  },
});

await crawler.addRequests([{ url: postUrl }]);
await crawler.run();
Actor.log.info('Done.');